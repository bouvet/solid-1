using System;
using System.Text.RegularExpressions;

namespace SRP.After
{
    public class CustomerValidator
    {
        public bool Validate(string name, string email)
        {
            if (string.IsNullOrEmpty(name))
                return false;
            var emailRegex = new Regex(@"\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}\b");
            if (!emailRegex.IsMatch(email))
                return false;
            return true;
        }
    }
}