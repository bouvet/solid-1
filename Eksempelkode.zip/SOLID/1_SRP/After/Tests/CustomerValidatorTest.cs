using NUnit.Framework;

namespace SRP.After.Tests
{
    [TestFixture]
    public class CustomerValidatorTest
    {
        [Test]
        public void Given_valid_name_and_email_Should_succeed()
        {
            var validator = new CustomerValidator();
            var result = validator.Validate("John Doe", "john@doe.com");
            Assert.IsTrue(result);
        }

        [Test]
        public void Given_empty_name_Should_fail()
        {
            var validator = new CustomerValidator();
            var result = validator.Validate("", "john@doe.com");
            Assert.IsFalse(result);
        }

        [Test]
        public void Given_invalid_email_Should_fail()
        {
            var validator = new CustomerValidator();
            var result = validator.Validate("John Doe", "john@doe");
            Assert.IsFalse(result);
        }
    }
}