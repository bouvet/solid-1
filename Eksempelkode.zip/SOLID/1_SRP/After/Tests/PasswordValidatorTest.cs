using NUnit.Framework;

namespace SRP.After.Tests
{
    [TestFixture]
    public class PasswordValidatorTest
    {
        [Test]
        public void Should_generate_valid_password()
        {
            var passwordGenerator = new PasswordGenerator();
            var password = passwordGenerator.GeneratePassword();
            Assert.AreEqual(4, password.Length);
        }
    }
}