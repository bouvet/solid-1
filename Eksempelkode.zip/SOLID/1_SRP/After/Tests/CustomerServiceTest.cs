﻿using NUnit.Framework;

namespace SRP.After.Tests
{
    [TestFixture]
    public class CustomerServiceTest
    {
        [Test]
        public void Given_valid_customer_data_Then_customer_is_created_successfully()
        {
            var customerService = new CustomerService();
            var customer = customerService.CreateCustomer("John Doe", "john@doe.com");

            Assert.IsNotNull(customer);
            Assert.AreEqual(customer.Name, "John Doe");
        }
    }
}