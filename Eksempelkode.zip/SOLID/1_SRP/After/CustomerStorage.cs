using System.Data.SqlClient;
using Dapper;

namespace SRP.After
{
    public class CustomerStorage
    {
        public void Save(Customer customer)
        {
            using (var connection = new SqlConnection("Server=myServerAddress;Database=myDataBase;User Id=myUsername;Password=myPassword"))
            {
                connection.Open();
                connection.Execute(@"INSERT INTO Customer VALUES(@name, @email)", new { name = customer.Name, email = customer.Email });
            }
        }
    }
}