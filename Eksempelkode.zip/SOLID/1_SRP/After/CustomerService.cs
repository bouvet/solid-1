﻿namespace SRP.After
{
    public class CustomerService
    {
        private readonly CustomerValidator _customerValidator = new CustomerValidator();
        private readonly PasswordGenerator _passwordGenerator = new PasswordGenerator();
        private readonly CustomerStorage _customerStorage = new CustomerStorage();
        private readonly EmailSender _emailSender = new EmailSender();

        public Customer CreateCustomer(string name, string email)
        {
            if (!_customerValidator.Validate(name, email))
                return null;

            var customer = new Customer {Name = name, Email = email};

            var password = _passwordGenerator.GeneratePassword();
            customer.Password = password;

            _customerStorage.Save(customer);

            _emailSender.SendEmail(email, password);

            return customer;
        }
    }
}