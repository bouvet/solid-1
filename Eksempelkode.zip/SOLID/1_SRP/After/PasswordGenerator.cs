using System;

namespace SRP.After
{
    public class PasswordGenerator
    {
        public string GeneratePassword()
        {
            var password = new Random().Next(1000, 9999).ToString();
            return password;
        }
    }
}