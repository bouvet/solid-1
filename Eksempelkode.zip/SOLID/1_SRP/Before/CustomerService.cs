﻿using System;
using System.Data.SqlClient;
using System.Net.Mail;
using System.Text.RegularExpressions;
using Dapper;

namespace SRP.Before
{
    public class CustomerService
    {
        public Customer CreateCustomer(string name, string email)
        {
            // Validate
            if (string.IsNullOrEmpty(name))
                return null;
            var emailRegex = new Regex(@"\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}\b");
            if (!emailRegex.IsMatch(email))
                return null;

            // Create customer
            var customer = new Customer();
            customer.Name = name;
            customer.Email = email;

            // Generate password
            var password = new Random().Next(1000, 9999).ToString();
            customer.Password = password;

            // Persist customer
            using (var connection = new SqlConnection("Server=myServerAddress;Database=myDataBase;User Id=myUsername;Password=myPassword"))
            {
                connection.Open();
                connection.Execute(@"INSERT INTO Customer VALUES(@name, @email)", new {name, email});
            }

            // Send email notification with password
            var smtpClient = new SmtpClient();
            smtpClient.Send("donotreply@company.com", email, "Generated password", "A new user has been created for you with the password " + password);

            return customer;
        }
    }
}