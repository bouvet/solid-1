﻿using System;
using System.Collections.Generic;

namespace DIP.After
{
    public interface IServiceLocator
    {
        T GetService<T>();
    }

    public class ServiceLocator : IServiceLocator
    {
        private static ServiceLocator _current;

        public static ServiceLocator Current
        {
            get
            {
                if (_current == null)
                    _current = new ServiceLocator();
                return _current;
            }
        }

        private readonly Dictionary<Type, object> _services = new Dictionary<Type, object>();

        public ServiceLocator()
        {
            _services.Add(typeof(ICustomerWrite), new DatabaseStorage());
        }

        public T GetService<T>()
        {
            if (!_services.ContainsKey(typeof(T)))
                throw new Exception("No service registered for type " + typeof(T).Name);
            return (T)_services[typeof (T)];
        }
    }
}