﻿namespace DIP.After
{
    public class CustomerService
    {
        private readonly ICustomerWrite _customerWrite;
        private readonly IPasswordGenerator _passwordGenerator;
        private readonly IEmailSender _emailSender;

        public CustomerService(ICustomerWrite customerWrite, IPasswordGenerator passwordGenerator, IEmailSender emailSender)
        {
            _customerWrite = customerWrite;
            _passwordGenerator = passwordGenerator;
            _emailSender = emailSender;
        }

        public Customer CreateCustomer(string name, string email, CustomerType customerType)
        {
            var customer = new Customer { Name = name, Email = email, Type = customerType };

            if (!CustomerValidatorFactory.GetValidatorFor(customer).Validate(customer))
                return null;

            var password = _passwordGenerator.GeneratePassword();
            customer.Password = password;

            _customerWrite.AddCustomer(customer);

            _emailSender.SendEmail(email, password);

            return customer;
        }
    }
}