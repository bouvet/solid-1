using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Xml;
using System.Xml.Serialization;
using Dapper;

namespace DIP.After
{
    public interface ICustomerRead
    {
        List<Customer> GetCustomers();        
    }

    public interface ICustomerWrite
    {
        void AddCustomer(Customer customer);
    }

    public interface IDatabaseConnection
    {
        string ConnectionString { get; set; }
    }

    public interface IFileConnection
    {
        string FileName { get; set; }
    }

    public class DatabaseStorage : ICustomerRead, ICustomerWrite, IDatabaseConnection
    {
        public string ConnectionString { get; set; }

        public void AddCustomer(Customer customer)
        {
            using (var connection = new SqlConnection(ConnectionString))
            {
                connection.Open();
                connection.Execute(@"INSERT INTO Customer VALUES(@name, @email)", new { name = customer.Name, email = customer.Email });
            }
        }

        public List<Customer> GetCustomers()
        {
            using (var connection = new SqlConnection(ConnectionString))
            {
                connection.Open();
                return connection.Query<Customer>(@"SELECT * FROM Customer").ToList();
            }
        }
    }

    public class FileStorage : ICustomerRead, ICustomerWrite, IFileConnection
    {
        public string FileName { get; set; }

        public void AddCustomer(Customer customer)
        {
            var customers = GetCustomers();
            customers.Add(customer);

            var xmlSerializer = new XmlSerializer(typeof(List<Customer>));
            using (var writer = XmlWriter.Create(FileName))
            {
                xmlSerializer.Serialize(writer, customers);
            }
        }

        public List<Customer> GetCustomers()
        {
            var xmlSerializer = new XmlSerializer(typeof(List<Customer>));
            using (var reader = XmlReader.Create(FileName))
            {
                return (List<Customer>)xmlSerializer.Deserialize(reader);
            }
        }
    }

    public class CRMStorage : ICustomerRead
    {
        public List<Customer> GetCustomers()
        {
            // Get customers from the CRM system
            return new List<Customer>();
        }
    }
}