using System.Net.Mail;

namespace DIP.After
{
    public interface IEmailSender
    {
        void SendEmail(string email, string password);
    }

    public class EmailSender : IEmailSender
    {
        public void SendEmail(string email, string password)
        {
            var smtpClient = new SmtpClient();
            smtpClient.Send("donotreply@company.com", email, "Generated password", "A new user has been created for you with the password " + password);
        }
    }
}