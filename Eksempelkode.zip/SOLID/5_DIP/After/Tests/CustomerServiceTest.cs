﻿using System;
using NUnit.Framework;

namespace DIP.After.Tests
{
    [TestFixture]
    public class CustomerServiceTest
    {
        [Test]
        public void Given_valid_customer_Then_customer_is_created()
        {
            var customerStorage = new MockCustomerStorage();
            var customerService = new CustomerService(customerStorage, new StrongPasswordGenerator(), new MockEmailSender());
            customerService.CreateCustomer("Test", "test@test.com", CustomerType.Private);

            Assert.AreEqual("Test", customerStorage.AddedCustomer.Name);
        }
    }

    public class MockCustomerStorage : ICustomerWrite
    {
        public Customer AddedCustomer { get; private set; }

        public void AddCustomer(Customer customer)
        {
            AddedCustomer = customer;
        }
    }

    public class MockEmailSender : IEmailSender
    {
        public void SendEmail(string email, string password)
        {
            Console.WriteLine("Email sent to " + email);
        }
    }
}