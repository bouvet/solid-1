namespace DIP.After
{
    public class Customer
    {
        public string Name { get; set; }
        public int? OrgNo { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public CustomerType Type { get; set; }
    }

    public enum CustomerType
    {
        Private = 1,
        Business = 2
    }
}