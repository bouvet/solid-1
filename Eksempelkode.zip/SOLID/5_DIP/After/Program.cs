﻿//using System;
//using Autofac;

//namespace DIP.After
//{
//    class Program
//    {
//        static void Main(string[] args)
//        {
//            var container = GetContainer();
//            var customerService = container.Resolve<CustomerService>();
//            var customer = customerService.CreateCustomer("John Doe", "john@doe.com", CustomerType.Private);
//            Console.WriteLine("Customer " + customer.Name + " created");
//        }

//        private static IContainer GetContainer()
//        {
//            var builder = new ContainerBuilder();
//            builder.RegisterType<CustomerService>();
//            builder.RegisterType<DatabaseStorage>().As<ICustomerWrite>();
//            builder.RegisterType<StrongPasswordGenerator>().As<IPasswordGenerator>();
//            builder.RegisterType<EmailSender>().As<IEmailSender>();
//            return builder.Build();
//        }
//    }
//}