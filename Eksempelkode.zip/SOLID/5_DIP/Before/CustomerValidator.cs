using System.Text.RegularExpressions;

namespace DIP.Before
{
    public abstract class CustomerValidator
    {
        public virtual bool Validate(Customer customer)
        {
            var emailRegex = new Regex(@"\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}\b");
            if (!emailRegex.IsMatch(customer.Email))
                return false;
            return true;
        }
    }

    public class PrivateCustomerValidator : CustomerValidator
    {
        public override bool Validate(Customer customer)
        {
            if (!base.Validate(customer))
                return false;
            if (string.IsNullOrEmpty(customer.Name))
                return false;
            return true;
        }
    }

    public class BusinessCustomerValidator : CustomerValidator
    {
        public override bool Validate(Customer customer)
        {
            if (!base.Validate(customer))
                return false;
            if (!customer.OrgNo.HasValue)
                return false;
            return true;
        }
    }
}