using System;

namespace DIP.Before
{
    public interface IPasswordGenerator
    {
        string GeneratePassword();
    }

    public class PasswordGenerator : IPasswordGenerator
    {
        public string GeneratePassword()
        {
            var password = new Random().Next(1000, 9999).ToString();
            return password;
        }
    }

    public class StrongPasswordGenerator : IPasswordGenerator
    {
        public string GeneratePassword()
        {
            return System.Web.Security.Membership.GeneratePassword(8, 1);
        }
    }
}