﻿using NUnit.Framework;

namespace DIP.Before.Tests
{
    [TestFixture]
    public class CustomerServiceTest
    {
        [Test]
        public void Given_valid_customer_Then_customer_is_created()
        {
            var customerStorage = new MockCustomerStorage();
            var customerService = new CustomerService(customerStorage);
            customerService.CreateCustomer("Test", "test@test.com", CustomerType.Private);

            Assert.AreEqual("Test", customerStorage.AddedCustomer.Name);
        }
    }

    public class MockCustomerStorage : ICustomerWrite
    {
        public Customer AddedCustomer { get; private set; }

        public void AddCustomer(Customer customer)
        {
            AddedCustomer = customer;
        }
    }
}