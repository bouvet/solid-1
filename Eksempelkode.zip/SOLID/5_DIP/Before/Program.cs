﻿using System;

namespace DIP.Before
{
    class Program
    {
        static void Main(string[] args)
        {
            var customerService = new CustomerService(new DatabaseStorage());
            var customer = customerService.CreateCustomer("John Doe", "john@doe.com", CustomerType.Private);
            Console.WriteLine("Customer " + customer.Name + " created");
        }
    }
}