﻿using System;

namespace DIP.Before
{
    public class CustomerValidatorFactory
    {
        public static CustomerValidator GetValidatorFor(Customer customer)
        {
            if (customer.Type == CustomerType.Private)
                return new PrivateCustomerValidator();
            if (customer.Type == CustomerType.Business)
                return new BusinessCustomerValidator();
            throw new NotSupportedException("No validator defined for customer type " + customer.Type);
        }
    }
}